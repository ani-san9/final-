document.getElementById("submit").addEventListener("click", function() {
    alert("Thank you, to be active, we will contact with you!");
  });

  $(document).ready(function(){
    $("#tp").click(function(){
      $("#form2").toggle();
    });
  });
