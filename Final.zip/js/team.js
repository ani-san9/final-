$(document).ready(function(){
    $("#so").click(function(){
      $("#how").slideToggle("slow");
    });
  });
